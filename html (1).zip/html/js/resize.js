function resize(selector){
    let element = document.getElementById(selector);
    console.log(element);
    var width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
    var height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    console.log(width);
    console.log(height);
    element.style.height = height+"px";
    element.style.width = width+"px";
}