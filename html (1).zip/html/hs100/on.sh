./hs100 $1 on
echo "on!"
