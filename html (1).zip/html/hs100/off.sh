./hs100 $1 off
echo "off!"
