<?php
$user = "blog";
$pass = "2LoadData!";
?>