git add . -- ":!update.sh :!W3School :!.git"
git commit -m "Update files"
git push
